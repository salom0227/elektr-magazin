'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import axios from 'axios';
import Link from 'next/link';
import { useCart } from '@/context/CartContext';

const API = process.env.NEXT_PUBLIC_API_URL;

const getCatIcon = (name = '') => {
  const map = { 'rozetka': '🔌', 'adapter': '🔄', 'usb': '📲', 'smart': '📱', 'kabel': '🔗', 'switch': '🔀' };
  for (const [k, v] of Object.entries(map)) {
    if (name.toLowerCase().includes(k)) return v;
  }
  return '⚡';
};

function CatalogContent() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [activeCategory, setActiveCategory] = useState(searchParams.get('category') || '');
  const [added, setAdded] = useState({});
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('');
  const { addToCart } = useCart();

  useEffect(() => {
    axios.get(`${API}/api/categories`).then(r => setCategories(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (activeCategory) params.append('category_id', activeCategory);
    axios.get(`${API}/api/products?${params}`)
      .then(r => {
        let data = r.data;
        if (sortBy === 'price_asc') data = [...data].sort((a, b) => a.price - b.price);
        if (sortBy === 'price_desc') data = [...data].sort((a, b) => b.price - a.price);
        setProducts(data);
      })
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [search, activeCategory, sortBy]);

  const handleAdd = (p) => {
    addToCart({ ...p, qty: 1 });
    setAdded(a => ({ ...a, [p.id]: true }));
    setTimeout(() => setAdded(a => ({ ...a, [p.id]: false })), 2000);
  };

  return (
    <div>
      {/* Header */}
      <div className="catalog-header">
        <div className="container">
          <div style={{ color: 'rgba(255,255,255,.6)', fontSize: 13, marginBottom: 6 }}>
            <Link href="/" style={{ color: 'rgba(255,255,255,.6)' }}>Bosh sahifa</Link>
            {' → '}
            <span style={{ color: 'white' }}>Katalog</span>
          </div>
          <h1 style={{ color: 'white', fontSize: 32, fontWeight: 800, marginBottom: 4 }}>Katalog</h1>
          <p style={{ color: 'rgba(255,255,255,.65)', fontSize: 15 }}>
            {products.length} ta mahsulot mavjud
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', marginTop: 16 }}>
            <form onSubmit={e => e.preventDefault()} className="catalog-search" style={{ flex: 1, maxWidth: 460 }}>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Mahsulot qidirish..."
              />
              <button type="submit">🔍</button>
            </form>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              style={{
                padding: '11px 16px', borderRadius: 12, border: '1.5px solid rgba(255,255,255,.3)',
                background: 'rgba(255,255,255,.12)', color: 'white',
                fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
                outline: 'none', backdropFilter: 'blur(8px)', cursor: 'pointer',
              }}
            >
              <option value="" style={{ color: '#111' }}>Saralash</option>
              <option value="price_asc" style={{ color: '#111' }}>Narx: arzon</option>
              <option value="price_desc" style={{ color: '#111' }}>Narx: qimmat</option>
            </select>
          </div>
        </div>
      </div>

      <div className="main-wrap">
        {/* Filter chips */}
        <div className="filter-chips">
          <button
            className={`chip${!activeCategory ? ' active' : ''}`}
            onClick={() => setActiveCategory('')}
          >
            Hammasi
          </button>
          {categories.map(c => (
            <button
              key={c.id}
              className={`chip${activeCategory === String(c.id) ? ' active' : ''}`}
              onClick={() => setActiveCategory(activeCategory === String(c.id) ? '' : String(c.id))}
            >
              {getCatIcon(c.name)} {c.name}
            </button>
          ))}
        </div>

        {/* Grid */}
        {loading ? (
          <div className="product-grid">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} style={{ borderRadius: 20, overflow: 'hidden' }}>
                <div className="skeleton" style={{ height: 200 }} />
                <div style={{ padding: 14, background: 'white' }}>
                  <div className="skeleton" style={{ height: 14, width: '60%', marginBottom: 8 }} />
                  <div className="skeleton" style={{ height: 14, width: '40%', marginBottom: 8 }} />
                  <div className="skeleton" style={{ height: 20, width: '50%' }} />
                </div>
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="empty-state">
            <div className="e-icon">🔍</div>
            <div className="e-text">Mahsulot topilmadi</div>
            <div className="e-sub">Boshqa so'z bilan qidiring yoki filterlarni olib tashlang</div>
            <button
              className="btn-green btn"
              style={{ marginTop: 20 }}
              onClick={() => { setSearch(''); setActiveCategory(''); }}
            >
              Filterlarni tozalash
            </button>
          </div>
        ) : (
          <div className="product-grid stagger">
            {products.map(p => (
              <div key={p.id} className="product-card card-3d anim-fade-up">
                <div className="card-shine" />
                <span className="p-badge new">Yangi</span>
                <button className="p-wish">♡</button>

                <Link href={`/product/${p.slug}`} style={{ textDecoration: 'none' }}>
                  <div className="p-img">
                    {p.image
                      ? <img src={p.image} alt={p.name} />
                      : <span style={{ fontSize: 56 }}>⚡</span>
                    }
                  </div>
                </Link>
                <div className="p-body">
                  <span className="p-cat">{p.category_name}</span>
                  <Link href={`/product/${p.slug}`} style={{ textDecoration: 'none' }}>
                    <div className="p-name">{p.name}</div>
                  </Link>
                  {p.brand && <div style={{ fontSize: 11, color: 'var(--gray-400)' }}>{p.brand}</div>}
                  <div style={{ display: 'flex', gap: 2, margin: '4px 0' }}>
                    {[1,2,3,4,5].map(s => <span key={s} style={{ fontSize: 11, color: '#f59e0b' }}>★</span>)}
                  </div>
                  <div className="p-price">
                    {Number(p.price).toLocaleString('uz-UZ')} <span>so'm</span>
                  </div>
                </div>
                <button
                  className={`p-btn${added[p.id] ? ' added' : ''}`}
                  onClick={() => handleAdd(p)}
                >
                  {added[p.id] ? '✅ Qo\'shildi' : '🛒 Savatchaga'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function CatalogPage() {
  return (
    <Suspense fallback={
      <div style={{ display: 'flex', justifyContent: 'center', padding: 80 }}>
        <div style={{ textAlign: 'center', color: 'var(--gray-400)' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>⚡</div>
          <div>Yuklanmoqda...</div>
        </div>
      </div>
    }>
      <CatalogContent />
    </Suspense>
  );
}
