// ──────────────────────────────────────────────
// components/CartContent.js
// ──────────────────────────────────────────────
'use client';
import { useCart } from '@/context/CartContext';
import Link from 'next/link';

export default function CartContent() {
  const { cart, removeFromCart, updateQty, total } = useCart();

  if (cart.length === 0) return (
    <div style={{
      minHeight: '70vh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', textAlign: 'center',
    }}>
      <div style={{ fontSize: 80, marginBottom: 16, animation: 'float 3s ease-in-out infinite' }}>🛒</div>
      <h2 style={{ fontSize: 24, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 8 }}>Savatcha bo'sh</h2>
      <p style={{ color: 'var(--gray-500)', marginBottom: 28 }}>Hali hech narsa qo'shilmagan</p>
      <Link href="/catalog" style={{
        padding: '13px 32px', borderRadius: 'var(--r-lg)',
        background: 'var(--g)', color: 'white',
        fontWeight: 800, fontSize: 15,
        boxShadow: 'var(--sh-green)', textDecoration: 'none',
        display: 'inline-block',
      }}>Xarid qilish →</Link>
    </div>
  );

  return (
    <div className="main-wrap page-enter">
      <h1 style={{ fontSize: 28, fontWeight: 800, color: 'var(--gray-900)', marginBottom: 24 }}>
        🛒 Savatcha
        <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--gray-400)', marginLeft: 10 }}>
          ({cart.length} ta mahsulot)
        </span>
      </h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20 }}>
        {/* Items */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {cart.map(item => (
            <div key={item.id} className="cart-item anim-fade-up">
              <div className="cart-item-img">
                {item.image
                  ? <img src={item.image} alt={item.name} />
                  : <span>⚡</span>
                }
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--gray-800)', marginBottom: 4 }}>
                  {item.name}
                </div>
                <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--g-dark)' }}>
                  {Number(item.price).toLocaleString('uz-UZ')} so'm
                </div>
              </div>
              <div className="qty-ctrl">
                <button className="qty-btn" onClick={() => updateQty(item.id, (item.qty || 1) - 1)}>−</button>
                <div className="qty-num">{item.qty || 1}</div>
                <button className="qty-btn" onClick={() => updateQty(item.id, (item.qty || 1) + 1)}>+</button>
              </div>
              <div style={{
                fontWeight: 800, fontSize: 15, color: 'var(--gray-800)',
                minWidth: 90, textAlign: 'right',
              }}>
                {(Number(item.price) * (item.qty || 1)).toLocaleString('uz-UZ')}
                <span style={{ fontSize: 11, color: 'var(--gray-400)', display: 'block', fontWeight: 500 }}>so'm</span>
              </div>
              <button onClick={() => removeFromCart(item.id)} style={{
                width: 32, height: 32, borderRadius: '50%',
                border: 'none', background: 'var(--gray-100)',
                cursor: 'pointer', fontSize: 16, color: 'var(--gray-500)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'background .2s',
              }}
                onMouseEnter={e => e.target.style.background = '#fee2e2'}
                onMouseLeave={e => e.target.style.background = 'var(--gray-100)'}
              >×</button>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div>
          <div className="checkout-card" style={{ position: 'sticky', top: 100 }}>
            <h3 style={{ fontSize: 17, fontWeight: 800, marginBottom: 20 }}>Buyurtma jami</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
              {cart.map(item => (
                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span style={{ color: 'var(--gray-600)' }}>{item.name} ×{item.qty || 1}</span>
                  <span style={{ fontWeight: 700 }}>
                    {(Number(item.price) * (item.qty || 1)).toLocaleString('uz-UZ')}
                  </span>
                </div>
              ))}
            </div>
            <div style={{ height: 1.5, background: 'var(--gray-200)', margin: '16px 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontSize: 13, color: 'var(--gray-500)' }}>Yetkazib berish</span>
              <span style={{ fontSize: 13, color: 'var(--g)', fontWeight: 700 }}>Bepul</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <span style={{ fontSize: 17, fontWeight: 800 }}>Jami:</span>
              <span style={{ fontSize: 24, fontWeight: 900, color: 'var(--g-dark)' }}>
                {total.toLocaleString('uz-UZ')} <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--gray-400)' }}>so'm</span>
              </span>
            </div>
            <Link href="/checkout" style={{ textDecoration: 'none', display: 'block' }}>
              <button style={{
                width: '100%', padding: '14px',
                background: 'var(--g)', color: 'white',
                border: 'none', borderRadius: 'var(--r-lg)',
                fontFamily: 'inherit', fontWeight: 800, fontSize: 16,
                cursor: 'pointer', transition: 'all .2s',
                boxShadow: 'var(--sh-green)',
              }}
                onMouseEnter={e => { e.target.style.background = 'var(--g-dark)'; e.target.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.target.style.background = 'var(--g)'; e.target.style.transform = 'translateY(0)'; }}
              >
                Buyurtma berish →
              </button>
            </Link>
            <Link href="/catalog" style={{
              display: 'block', textAlign: 'center', marginTop: 12,
              fontSize: 13, color: 'var(--gray-500)', textDecoration: 'none',
            }}>← Xarid davom ettirish</Link>
          </div>
        </div>
      </div>
    </div>
  );
}


// ──────────────────────────────────────────────
// components/CheckoutContent.js
// ──────────────────────────────────────────────
// (separate export below — copy to components/CheckoutContent.js)
