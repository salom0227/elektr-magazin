'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useCart } from '@/context/CartContext';
import { useState, useEffect } from 'react';

export default function Navbar() {
  const { cart } = useCart();
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [search, setSearch] = useState('');

  const count = cart.reduce((s, i) => s + (i.qty || 1), 0);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) window.location.href = `/catalog?search=${encodeURIComponent(search.trim())}`;
  };

  const navLinks = [
    { href: '/', label: 'Bosh sahifa' },
    { href: '/catalog', label: 'Katalog' },
  ];

  return (
    <>
      {/* Ticker */}
      <div className="ticker-wrap">
        <div className="ticker-inner">
          {[...Array(2)].map((_, ri) =>
            ['⚡ Bepul yetkazib berish — 500 000 so\'mdan yuqori buyurtmalarda',
             '🎁 Yangi mijozlarga 10% chegirma',
             '🔒 Kafolatlangan sifat',
             '📞 Qo\'llab-quvvatlash: 24/7',
             '🏷️ Haftaning mahsuloti: Smart rozetka -20%'].map((t, i) => (
              <span key={`${ri}-${i}`} className="ticker-item">{t}</span>
            ))
          )}
        </div>
      </div>

      <nav className={`navbar${scrolled ? ' scrolled' : ''}`}>
        <div className="navbar-inner">
          {/* Logo */}
          <Link href="/" className="nav-logo" style={{ textDecoration: 'none' }}>
            <div className="nav-logo-icon">⚡</div>
            <span className="nav-logo-text">
              Elektr<em>Baza</em>
            </span>
          </Link>

          {/* Nav links */}
          <div className="nav-links">
            {navLinks.map(l => (
              <Link key={l.href} href={l.href}
                className={`nav-link${pathname === l.href ? ' active' : ''}`}>
                {l.label}
              </Link>
            ))}
          </div>

          {/* Search */}
          <form onSubmit={handleSearch} className="nav-search" style={{ flex: 1, maxWidth: 440 }}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Mahsulot qidirish..."
            />
            <button type="submit" style={{ color: 'white' }}>🔍</button>
          </form>

          {/* Actions */}
          <div className="nav-actions">
            <Link href="/cart" className="nav-btn nav-btn-cart" style={{ textDecoration: 'none' }}>
              🛒
              <span className="hidden sm:inline" style={{ display: 'inline' }}> Savatcha</span>
              {count > 0 && <span className="nav-badge">{count}</span>}
            </Link>
          </div>
        </div>
      </nav>
    </>
  );
}
